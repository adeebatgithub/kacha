

class GroupPoints:
    First: int = 10
    Second: int = 5
    Third: int = 3


class IndividualPoints:
    First: int = 5
    Second: int = 3
    Third: int = 1


class Grade:
    A: int = 5
    B: int = 3
    C: int = 1
    D: int = 0
    E: int = 0
